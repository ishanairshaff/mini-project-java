import javax.swing.*;
import java.awt.*;

public class TechnicalOfficerDashboard extends JFrame {

    public TechnicalOfficerDashboard() {
        // Setting up the frame
        setTitle("Technical Officer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 800);
        setLayout(new BorderLayout());

        // Creating a panel for the main buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS)); // Align buttons vertically
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Add padding around the panel

        // Adding main buttons to the panel with gaps
        buttonPanel.add(createButton("View Attendance"));
        buttonPanel.add(Box.createVerticalStrut(15)); // Add gap between buttons
        buttonPanel.add(createButton("Update Attendance"));
        buttonPanel.add(Box.createVerticalStrut(15)); // Add gap between buttons
        buttonPanel.add(createButton("Add Attendance"));
        buttonPanel.add(Box.createVerticalStrut(15)); // Add gap between buttons
        buttonPanel.add(createButton("Add Medicals"));

        // Adding the panel to the left side of the frame
        add(buttonPanel, BorderLayout.WEST);

        // Creating the "Logout" button with reduced length and placing it in the bottom-left corner
        JButton logoutButton = new JButton("Logout");
        logoutButton.setPreferredSize(new Dimension(80, 30)); // Reduced size for the Logout button
        logoutButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(null, "Logging out...");
            System.exit(0); // Exits the application
        });

        // Wrapping the Logout button in a separate panel for bottom-left alignment
        JPanel logoutPanel = new JPanel(new BorderLayout());
        logoutPanel.add(logoutButton, BorderLayout.SOUTH);
        logoutPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 0)); // Align Logout button to the bottom-left
        add(logoutPanel, BorderLayout.SOUTH);

        // Making the frame visible
        setVisible(true);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.LEFT_ALIGNMENT); // Align button to the left
        button.setMaximumSize(new Dimension(200, 40)); // Consistent size for main buttons
        return button;
    }

    public static void main(String[] args) {
        // Instantiate and display the dashboard
        SwingUtilities.invokeLater(() -> new TechnicalOfficerDashboard());
    }
}
